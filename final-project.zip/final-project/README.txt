Thanks for viewing our term project for CSE 141L!

In this folder, we have all the hardware components and the machine codes and testbenches for 3 programs. 

Before doing simulation, remember to change the path to the machine code file in instr-ROM.sv module. Include only testbench for program 1 when simulating program 1, similarly for program 2 and 3.

Best,

Chenrong Gu & Zhaochen Zhu